अपना गाँव श्रीरामपुर वेबसाइट

इस ZIP में index.html और images/ फ़ोल्डर है। सभी फ़ाइलें और images/ फ़ोल्डर GitHub repository के root में अपलोड करें; केवल index.html अकेले अपलोड करने से तस्वीरें नहीं दिखेंगी।

GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root) > Save.
